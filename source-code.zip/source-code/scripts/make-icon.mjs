import { app, BrowserWindow } from 'electron'
import { mkdirSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const out = join(here, '..', 'build', 'icon.png')

const ghost = `
<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#7c4dff"/>
      <stop offset="0.55" stop-color="#a24bff"/>
      <stop offset="1" stop-color="#ff6d3a"/>
    </linearGradient>
    <linearGradient id="ghostFill" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#ffffff"/>
      <stop offset="1" stop-color="#f3e8ff"/>
    </linearGradient>
    <filter id="soft" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="10" stdDeviation="14" flood-color="#2a0b45" flood-opacity="0.35"/>
    </filter>
  </defs>
  <rect x="0" y="0" width="512" height="512" rx="118" fill="url(#bg)"/>
  <circle cx="392" cy="112" r="86" fill="#ffffff" opacity="0.12"/>
  <circle cx="116" cy="418" r="110" fill="#000000" opacity="0.10"/>
  <g filter="url(#soft)" transform="translate(76 66) scale(15)">
    <path d="M12 2.2c-4.9 0-8.5 3.7-8.5 8.6v9.5c0 1.2 1.4 1.8 2.3 1l1.4-1.4 1.6 1.6c.5.5 1.3.5 1.8 0l1.4-1.5 1.4 1.5c.5.5 1.3.5 1.8 0l1.6-1.6 1.4 1.4c.9.8 2.3.2 2.3-1v-9.5c0-4.9-3.6-8.6-8.5-8.6Z" fill="url(#ghostFill)"/>
    <circle cx="9.1" cy="10.2" r="1.42" fill="#3a1765"/>
    <circle cx="14.9" cy="10.2" r="1.42" fill="#3a1765"/>
    <ellipse cx="12" cy="14.1" rx="1.6" ry="1.15" fill="#3a1765" opacity="0.85"/>
  </g>
</svg>`

const page = `<!doctype html><html><head><meta charset="utf-8"><style>
  html,body{margin:0;width:512px;height:512px;background:transparent;overflow:hidden}
  body{display:grid;place-items:center}
  svg{width:512px;height:512px;display:block}
</style></head><body>${ghost}</body></html>`

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const failsafe = setTimeout(() => {
  console.error('icon: timeout')
  app.exit(1)
}, 40000)

async function grab(win) {
  const image = await win.webContents.capturePage()
  if (image && !image.isEmpty() && image.getSize().width > 0) return image
  return null
}

async function main() {
  const win = new BrowserWindow({
    width: 512,
    height: 512,
    x: -1600,
    y: -1600,
    show: false,
    frame: false,
    transparent: true,
    skipTaskbar: true,
    focusable: false,
    hasShadow: false,
    webPreferences: { backgroundThrottling: false, sandbox: true },
  })

  win.webContents.on('render-process-gone', (_e, d) => console.error('icon: renderer gone:', d.reason))
  await win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(page))
  await sleep(600)

  let image = await grab(win)
  console.log(`icon: hidden -> ${image ? image.getSize().width + 'x' + image.getSize().height : 'empty'}`)

  if (!image) {
    win.setOpacity(0)
    win.showInactive()
    for (let i = 0; i < 14 && !image; i += 1) {
      await sleep(250)
      image = await grab(win)
    }
    console.log(`icon: transparent -> ${image ? image.getSize().width + 'x' + image.getSize().height : 'empty'}`)
  }

  if (!image) {
    win.setOpacity(1)
    win.showInactive()
    await sleep(500)
    image = await grab(win)
    console.log(`icon: visible -> ${image ? image.getSize().width + 'x' + image.getSize().height : 'empty'}`)
  }

  if (!image) {
    console.error('icon: no frame captured')
    app.exit(1)
    return
  }

  const png = image.toPNG()
  mkdirSync(dirname(out), { recursive: true })
  writeFileSync(out, png)
  console.log(`icon: saved ${out} (${png.length} bytes, ${image.getSize().width}x${image.getSize().height})`)

  clearTimeout(failsafe)
  win.destroy()
  app.exit(0)
}

app.whenReady().then(main).catch((err) => {
  console.error('icon: failed:', err)
  app.exit(1)
})
