export type SearchEngineId = 'yandex' | 'google' | 'duckduckgo' | 'bing'

export interface TabInfo {
  id: number
  title: string
  /** Реальный URL. Для новой вкладки — пустая строка. */
  url: string
  /** URL в том виде, в котором его можно показать в адресной строке. */
  displayUrl: string
  favicon: string | null
  loading: boolean
  canGoBack: boolean
  canGoForward: boolean
  isNewTab: boolean
  audible: boolean
  error: { code: number; description: string; url: string } | null
}

export interface ThemeInfo {
  scheme: 'light' | 'dark'
  accent: string
  motion: 'expressive' | 'standard'
}

export interface WindowInfo {
  maximized: boolean
  fullscreen: boolean
  focused: boolean
}

export interface AppState {
  tabs: TabInfo[]
  activeId: number | null
  theme: ThemeInfo
  window: WindowInfo
  searchEngine: SearchEngineId
  settingsOpen: boolean
}

export interface SettingsPatch {
  scheme?: 'auto' | 'light' | 'dark'
  accent?: string | null
  searchEngine?: SearchEngineId
}

export interface GhostApi {
  platform: string
  version: string
  chromeVersion: string
  invoke: {
    state(): Promise<AppState>
    createTab(url?: string, background?: boolean): Promise<number>
    closeTab(id: number): Promise<void>
    selectTab(id: number): Promise<void>
    reopenTab(): Promise<void>
    navigate(id: number, url: string): Promise<void>
    nav(action: 'back' | 'forward' | 'reload' | 'hard-reload' | 'stop' | 'home'): Promise<void>
    setZoom(delta: number | 'reset'): Promise<void>
    toggleDevTools(): Promise<void>
    setOverlay(open: boolean): Promise<void>
    applySettings(patch: SettingsPatch): Promise<AppState>
    getSettings(): Promise<{ scheme: 'auto' | 'light' | 'dark'; accent: string | null; searchEngine: SearchEngineId }>
  }
  window: {
    minimize(): void
    toggleMaximize(): void
    close(): void
    toggleFullscreen(): void
  }
  setChromeHeight(height: number): void
  onState(cb: (state: AppState) => void): () => void
  onFocusOmnibox(cb: () => void): () => void
  onCloseOverlay(cb: () => void): () => void
  onToast(cb: (text: string) => void): () => void
}
