import '@m3e/web/theme'
import '@m3e/web/icon'
import '@m3e/web/icon-button'
import '@m3e/web/search'
import '@m3e/web/snackbar'

import '@m3e/icons/outlined/add'
import '@m3e/icons/outlined/arrow_back'
import '@m3e/icons/outlined/arrow_forward'
import '@m3e/icons/outlined/refresh'
import '@m3e/icons/outlined/home'
import '@m3e/icons/outlined/close'
import '@m3e/icons/outlined/settings'
import '@m3e/icons/outlined/search'
import '@m3e/icons/outlined/lock'
import '@m3e/icons/outlined/language'

import './styles.css'
import type { AppState, GhostApi, SearchEngineId, SettingsPatch, TabInfo } from '../../shared/types'

declare global {
  interface Window {
    ghost: GhostApi
  }
}

declare const M3eSnackbar: { open(text: string): void }

const api = window.ghost

const $ = <T extends Element>(sel: string): T => {
  const el = document.querySelector<T>(sel)
  if (!el) throw new Error(`нет элемента ${sel}`)
  return el
}

const chromeEl = $('#chrome') as HTMLElement
const tabsEl = $('#tabs') as HTMLElement
const address = $('#address') as HTMLInputElement
const themeEl = $('#theme') as HTMLElement
const progressEl = $('#progress') as HTMLElement
const reloadIcon = $('#reload-icon') as HTMLElement
const omniLeading = $('#omni-leading') as HTMLElement

const btnBack = $('#btn-back') as HTMLElement
const btnForward = $('#btn-forward') as HTMLElement
const btnReload = $('#btn-reload') as HTMLElement
const btnSettings = $('#btn-settings') as HTMLElement

const scrim = $('#scrim') as HTMLElement
const settingsPanel = $('#settings') as HTMLElement
const schemeRow = $('#scheme-row') as HTMLElement
const engineRow = $('#engine-row') as HTMLElement
const accentRow = $('#accent-row') as HTMLElement

let state: AppState | null = null
let prefs: Awaited<ReturnType<GhostApi['invoke']['getSettings']>> | null = null
let settingsOpen = false
let closeTimer: number | undefined

const GHOST_SVG = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6c-4.6 0-8 3.5-8 8.1v9.1c0 1.1 1.3 1.7 2.1.9l1.3-1.3 1.5 1.5c.5.5 1.2.5 1.7 0l1.4-1.4 1.4 1.4c.5.5 1.2.5 1.7 0l1.5-1.5 1.3 1.3c.8.8 2.1.2 2.1-.9v-9.1c0-4.6-3.4-8.1-8-8.1Z" fill="currentColor"/></svg>`

const CLOSE_SVG = `<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.8 2.8l6.4 6.4M9.2 2.8L2.8 9.2"/></svg>`

const ACCENTS = [
  '#6a4bd8',
  '#006a6a',
  '#0061a4',
  '#8e4585',
  '#b3261e',
  '#386a20',
  '#7d5260',
  '#f4511e',
  '#0b57d0',
  '#c58b00',
]

const ENGINES: { id: SearchEngineId; label: string }[] = [
  { id: 'yandex', label: 'Яндекс' },
  { id: 'google', label: 'Google' },
  { id: 'duckduckgo', label: 'DuckDuckGo' },
  { id: 'bing', label: 'Bing' },
]

function activeTab(): TabInfo | null {
  if (!state || state.activeId === null) return null
  const id = state.activeId
  return state.tabs.find((t) => t.id === id) ?? null
}

function applyTheme(): void {
  if (!state) return
  themeEl.setAttribute('color', state.theme.accent)
  themeEl.setAttribute('scheme', state.theme.scheme)
  document.documentElement.dataset.scheme = state.theme.scheme
  document.documentElement.style.colorScheme = state.theme.scheme
}

function renderTabs(): void {
  if (!state) return
  const scroll = tabsEl.scrollLeft
  tabsEl.replaceChildren()

  for (const tab of state.tabs) {
    const el = document.createElement('div')
    el.className = 'tab' + (tab.id === state.activeId ? ' active' : '')
    el.dataset.id = String(tab.id)
    el.setAttribute('role', 'tab')
    el.setAttribute('aria-selected', tab.id === state.activeId ? 'true' : 'false')
    el.title = tab.title

    const favicon = document.createElement('div')
    favicon.className = 'tab-favicon'
    if (tab.loading) {
      const spinner = document.createElement('span')
      spinner.className = 'spinner'
      favicon.append(spinner)
    } else if (tab.favicon) {
      const img = document.createElement('img')
      img.src = tab.favicon
      img.alt = ''
      img.addEventListener('error', () => {
        img.remove()
        favicon.innerHTML = GHOST_SVG
      })
      favicon.append(img)
    } else {
      favicon.innerHTML = GHOST_SVG
    }

    const title = document.createElement('span')
    title.className = 'tab-title'
    title.textContent = tab.title

    const close = document.createElement('button')
    close.className = 'tab-close'
    close.type = 'button'
    close.title = 'Закрыть вкладку'
    close.setAttribute('aria-label', 'Закрыть вкладку')
    close.innerHTML = CLOSE_SVG
    close.addEventListener('click', (e) => {
      e.stopPropagation()
      void api.invoke.closeTab(tab.id)
    })

    el.append(favicon, title, close)
    el.addEventListener('click', () => void api.invoke.selectTab(tab.id))
    el.addEventListener('auxclick', (e) => {
      if (e.button === 1) {
        e.preventDefault()
        void api.invoke.closeTab(tab.id)
      }
    })
    tabsEl.append(el)
  }

  tabsEl.scrollLeft = scroll
}

function renderToolbar(): void {
  const tab = activeTab()
  const focused = document.activeElement === address
  if (!focused) {
    address.value = tab?.displayUrl ?? ''
  }

  btnBack.toggleAttribute('disabled', !tab?.canGoBack)
  btnForward.toggleAttribute('disabled', !tab?.canGoForward)

  const loading = tab?.loading ?? false
  reloadIcon.setAttribute('name', loading ? 'close' : 'refresh')
  btnReload.title = loading ? 'Остановить загрузку' : 'Обновить (Ctrl+R)'

  progressEl.classList.toggle('loading', loading)

  const url = tab?.url ?? ''
  if (!url) omniLeading.setAttribute('name', 'search')
  else if (url.startsWith('https://')) omniLeading.setAttribute('name', 'lock')
  else omniLeading.setAttribute('name', 'language')
}

function renderWindow(): void {
  if (!state) return
  const maxBtn = $('#win-max') as HTMLElement
  const icon = $('#win-max-icon') as SVGElement

  if (state.window.maximized) {
    maxBtn.title = 'Восстановить'
    maxBtn.setAttribute('aria-label', 'Восстановить')
    icon.innerHTML = '<rect x="2.2" y="3.8" width="6" height="6" rx="1" /><path d="M4.2 3.8V2.6h5.2v5.2H8.2" />'
  } else {
    maxBtn.title = 'Развернуть'
    maxBtn.setAttribute('aria-label', 'Развернуть')
    icon.innerHTML = '<rect x="2.2" y="2.2" width="7.6" height="7.6" rx="1.1" />'
  }

  chromeEl.hidden = state.window.fullscreen
  measureChrome()
}

function measureChrome(): void {
  const height = chromeEl.hidden ? 0 : Math.round(chromeEl.getBoundingClientRect().height)
  document.documentElement.style.setProperty('--chrome-h', `${height}px`)
  api.setChromeHeight(height)
}

function applyState(next: AppState): void {
  state = next
  applyTheme()
  renderTabs()
  renderToolbar()
  renderWindow()
}

function openSettings(): void {
  if (closeTimer !== undefined) {
    window.clearTimeout(closeTimer)
    closeTimer = undefined
  }
  settingsPanel.classList.remove('closing')
  settingsOpen = true
  scrim.hidden = false
  settingsPanel.hidden = false
  void api.invoke.setOverlay(true)
  void refreshPrefs()
}

function closeSettings(): void {
  if (!settingsOpen && settingsPanel.hidden && closeTimer === undefined) return
  settingsOpen = false
  scrim.hidden = true
  void api.invoke.setOverlay(false)
  if (settingsPanel.hidden || closeTimer !== undefined) return
  settingsPanel.classList.add('closing')
  closeTimer = window.setTimeout(() => {
    closeTimer = undefined
    settingsPanel.classList.remove('closing')
    settingsPanel.hidden = true
  }, 190)
}

async function refreshPrefs(): Promise<void> {
  prefs = await api.invoke.getSettings()
  renderPrefs()
}

function renderPrefs(): void {
  if (!prefs) return
  for (const btn of schemeRow.querySelectorAll<HTMLElement>('[data-scheme]')) {
    btn.classList.toggle('selected', btn.dataset.scheme === prefs.scheme)
  }
  for (const btn of engineRow.querySelectorAll<HTMLElement>('[data-engine]')) {
    btn.classList.toggle('selected', btn.dataset.engine === prefs.searchEngine)
  }
  for (const btn of accentRow.querySelectorAll<HTMLElement>('[data-accent]')) {
    btn.classList.toggle('selected', btn.dataset.accent === prefs.accent)
  }
  $('#accent-system')?.classList.toggle('selected', prefs.accent === null)
}

async function applySettings(patch: SettingsPatch): Promise<void> {
  const next = await api.invoke.applySettings(patch)
  state = next
  applyTheme()
  await refreshPrefs()
}

function buildSettings(): void {
  for (const hex of ACCENTS) {
    const b = document.createElement('button')
    b.className = 'swatch'
    b.type = 'button'
    b.dataset.accent = hex
    b.style.background = hex
    b.title = hex
    b.setAttribute('aria-label', `Акцент ${hex}`)
    b.addEventListener('click', () => void applySettings({ accent: hex }))
    accentRow.append(b)
  }

  const customWrap = document.createElement('label')
  customWrap.className = 'swatch'
  customWrap.title = 'Свой цвет'
  customWrap.style.background =
    'conic-gradient(#ff5f57, #febc2e, #28c840, #40a9ff, #a259ff, #ff5f57)'
  const input = document.createElement('input')
  input.type = 'color'
  input.value = prefs?.accent ?? '#6a4bd8'
  input.style.position = 'absolute'
  input.style.opacity = '0'
  input.style.width = '100%'
  input.style.height = '100%'
  input.style.cursor = 'pointer'
  input.addEventListener('change', () => void applySettings({ accent: input.value }))
  customWrap.append(input)
  accentRow.append(customWrap)

  for (const btn of schemeRow.querySelectorAll<HTMLElement>('[data-scheme]')) {
    btn.addEventListener('click', () => {
      const scheme = btn.dataset.scheme as 'auto' | 'light' | 'dark'
      void applySettings({ scheme })
    })
  }

  for (const btn of engineRow.querySelectorAll<HTMLElement>('[data-engine]')) {
    btn.addEventListener('click', () => {
      const engine = btn.dataset.engine as SearchEngineId
      void applySettings({ searchEngine: engine })
    })
  }

  $('#accent-system')?.addEventListener('click', () => void applySettings({ accent: null }))
}

function wireChrome(): void {
  $('#new-tab')?.addEventListener('click', () => void api.invoke.createTab())
  btnBack.addEventListener('click', () => void api.invoke.nav('back'))
  btnForward.addEventListener('click', () => void api.invoke.nav('forward'))
  btnReload.addEventListener('click', () => {
    const tab = activeTab()
    void api.invoke.nav(tab?.loading ? 'stop' : 'reload')
  })
  $('#btn-home')?.addEventListener('click', () => void api.invoke.nav('home'))
  $('#btn-settings')?.addEventListener('click', () => openSettings())

  $('#win-min')?.addEventListener('click', () => api.window.minimize())
  $('#win-max')?.addEventListener('click', () => api.window.toggleMaximize())
  $('#win-close')?.addEventListener('click', () => api.window.close())

  $('#settings-close')?.addEventListener('click', closeSettings)
  scrim.addEventListener('click', closeSettings)

  address.addEventListener('focus', () => address.select())
  address.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      const tab = activeTab()
      if (!tab) return
      const value = address.value.trim()
      address.blur()
      if (value) void api.invoke.navigate(tab.id, value)
    } else if (e.key === 'Escape') {
      e.preventDefault()
      address.value = activeTab()?.displayUrl ?? ''
      address.blur()
    }
  })

  // не даём странице перехватывать ввод, когда фокус в адресной строке
  address.addEventListener('keydown', (e) => e.stopPropagation(), true)

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && settingsOpen) {
      e.preventDefault()
      closeSettings()
    }
  })

  const ro = new ResizeObserver(() => measureChrome())
  ro.observe(chromeEl)
}

api.onState((next) => applyState(next))
api.onFocusOmnibox(() => {
  address.focus()
  address.select()
})
api.onCloseOverlay(() => {
  if (settingsOpen) closeSettings()
})
api.onToast((text) => {
  try {
    M3eSnackbar.open(text)
  } catch {
    console.log('[toast]', text)
  }
})

async function init(): Promise<void> {
  buildSettings()
  wireChrome()
  $('#ver')!.textContent = '0.1.0'
  $('#electron-ver')!.textContent = api.version
  $('#chromium-ver')!.textContent = api.chromeVersion
  await refreshPrefs()
  const initial = await api.invoke.state()
  applyState(initial)
  measureChrome()
}

void init()
