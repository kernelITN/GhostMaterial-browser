import '@m3e/web/theme'
import '@m3e/web/icon'
import '@m3e/web/search'

import '@m3e/icons/outlined/search'
import '@m3e/icons/outlined/add'
import '@m3e/icons/outlined/close'
import '@m3e/icons/outlined/arrow_outward'

type Engine = 'yandex' | 'google' | 'duckduckgo' | 'bing'

interface Shortcut {
  name: string
  url: string
  color: string
  custom?: boolean
}

const $ = <T extends Element>(sel: string): T => {
  const el = document.querySelector<T>(sel)
  if (!el) throw new Error(`нет элемента ${sel}`)
  return el
}

const themeEl = $('#theme') as HTMLElement
const greetingEl = $('#greeting') as HTMLElement
const sublineEl = $('#subline') as HTMLElement
const searchBar = $('#search') as HTMLElement
const input = $('#q') as HTMLInputElement
const tilesEl = $('#tiles') as HTMLElement

const params = new URLSearchParams(location.search)
const scheme = params.get('scheme') === 'light' ? 'light' : 'dark'
const accent = params.get('accent') || '#6a4bd8'
const engineParam = params.get('engine') as Engine | null

const ENGINES: Record<Engine, { label: string; placeholder: string; search: (q: string) => string }> = {
  yandex: {
    label: 'Яндекс',
    placeholder: 'Поиск в Яндексе или адрес сайта',
    search: (q) => `https://yandex.ru/search/?text=${encodeURIComponent(q)}`,
  },
  google: {
    label: 'Google',
    placeholder: 'Поиск в Google или адрес сайта',
    search: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
  },
  duckduckgo: {
    label: 'DuckDuckGo',
    placeholder: 'Поиск в DuckDuckGo или адрес сайта',
    search: (q) => `https://duckduckgo.com/?q=${encodeURIComponent(q)}`,
  },
  bing: {
    label: 'Bing',
    placeholder: 'Поиск в Bing или адрес сайта',
    search: (q) => `https://www.bing.com/search?q=${encodeURIComponent(q)}`,
  },
}

const engine: Engine = engineParam && engineParam in ENGINES ? engineParam : 'yandex'

const DEFAULTS: Shortcut[] = [
  { name: 'Яндекс', url: 'https://ya.ru', color: '#fc3f1d' },
  { name: 'YouTube', url: 'https://www.youtube.com', color: '#ff0033' },
  { name: 'ВКонтакте', url: 'https://vk.com', color: '#0077ff' },
  { name: 'Telegram', url: 'https://web.telegram.org', color: '#2aabee' },
  { name: 'GitHub', url: 'https://github.com', color: '#6e7b8b' },
  { name: 'Кинопоиск', url: 'https://www.kinopoisk.ru', color: '#ff5500' },
  { name: 'Хабр', url: 'https://habr.com', color: '#5a9bb5' },
  { name: 'Википедия', url: 'https://ru.wikipedia.org', color: '#8a8f98' },
]

const STORAGE_KEY = 'ghostmaterial:shortcuts'

function loadShortcuts(): Shortcut[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return [...DEFAULTS]
    const parsed = JSON.parse(raw) as Shortcut[]
    if (!Array.isArray(parsed)) return [...DEFAULTS]
    return parsed.filter((s) => s && typeof s.url === 'string' && typeof s.name === 'string')
  } catch {
    return [...DEFAULTS]
  }
}

function saveShortcuts(list: Shortcut[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list.filter((s) => s.custom)))
  } catch {
    /* приватный режим — просто не сохраняем */
  }
}

let shortcuts = loadShortcuts()

function applyTheme(): void {
  themeEl.setAttribute('color', accent)
  themeEl.setAttribute('scheme', scheme)
  document.documentElement.dataset.scheme = scheme
  document.documentElement.style.colorScheme = scheme
  document.documentElement.style.setProperty('--accent', accent)
}

function greet(): void {
  const now = new Date()
  const h = now.getHours()
  const word =
    h >= 5 && h < 11 ? 'Доброе утро' : h >= 11 && h < 18 ? 'Добрый день' : h >= 18 && h < 23 ? 'Добрый вечер' : 'Доброй ночи'
  greetingEl.textContent = word

  const date = now.toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' })
  sublineEl.textContent = `${date.charAt(0).toUpperCase()}${date.slice(1)} · ${ENGINES[engine].label} в один клик`
}

function initials(name: string): string {
  const clean = name.trim()
  if (!clean) return '?'
  const words = clean.split(/\s+/)
  if (words.length > 1) return (words[0][0] + words[1][0]).toUpperCase()
  return clean.slice(0, 2).charAt(0).toUpperCase() + clean.slice(1, 2)
}

function ensureUrl(raw: string): string | null {
  const text = raw.trim()
  if (!text) return null
  if (/^(https?|file):\/\//i.test(text)) return text
  if (/^[a-z][a-z0-9+.-]*:/i.test(text) && !/^\d+$/.test(text)) return null
  const looksLikeHost =
    /^[^\s/]+\.[^\s]{2,}(\/.*)?$/i.test(text) ||
    /^localhost(:\d+)?(\/.*)?$/i.test(text) ||
    /^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(text)
  if (looksLikeHost) return `https://${text}`
  return null
}

function navigate(raw: string): void {
  const text = raw.trim()
  if (!text) return
  const url = ensureUrl(text)
  location.href = url ?? ENGINES[engine].search(text)
}

function openEditor(): void {
  const scrim = $('#editor-scrim') as HTMLElement
  const editor = $('#editor') as HTMLElement
  const name = $('#editor-name') as HTMLInputElement
  const url = $('#editor-url') as HTMLInputElement
  name.value = ''
  url.value = ''
  scrim.hidden = false
  editor.hidden = false
  name.focus()
}

function closeEditor(): void {
  ;($('#editor-scrim') as HTMLElement).hidden = true
  ;($('#editor') as HTMLElement).hidden = true
}

function saveEditor(): void {
  const name = ($('#editor-name') as HTMLInputElement).value.trim()
  const rawUrl = ($('#editor-url') as HTMLInputElement).value.trim()
  const url = ensureUrl(rawUrl)
  if (!name || !url) {
    ;($('#editor-url') as HTMLInputElement).focus()
    return
  }
  let host = name
  try {
    host = new URL(url).hostname.replace(/^www\./, '')
  } catch {
    /* оставляем имя */
  }
  const palette = ['#6a4bd8', '#006a6a', '#0061a4', '#8e4585', '#b3261e', '#386a20', '#c58b00']
  const color = palette[shortcuts.length % palette.length]
  const next = [...shortcuts, { name: name || host, url, color, custom: true }]
  shortcuts = next
  saveShortcuts(next)
  renderTiles()
  closeEditor()
}

function renderTiles(): void {
  tilesEl.replaceChildren()

  for (const item of shortcuts) {
    const tile = document.createElement('div')
    tile.className = 'tile-wrap'

    const link = document.createElement('a')
    link.className = 'tile'
    link.href = item.url
    link.title = `${item.name} — ${item.url}`
    link.addEventListener('click', (e) => {
      e.preventDefault()
      navigate(item.url)
    })

    const badge = document.createElement('span')
    badge.className = 'badge'
    badge.style.setProperty('--tile-color', item.color)
    badge.textContent = initials(item.name)

    const name = document.createElement('span')
    name.className = 'tile-name'
    name.textContent = item.name

    link.append(badge, name)

    if (item.custom) {
      const remove = document.createElement('button')
      remove.className = 'tile-remove'
      remove.type = 'button'
      remove.title = 'Удалить ссылку'
      remove.setAttribute('aria-label', `Удалить ${item.name}`)
      remove.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7l10 10M17 7L7 17"/></svg>'
      remove.addEventListener('click', (e) => {
        e.preventDefault()
        e.stopPropagation()
        shortcuts = shortcuts.filter((s) => s !== item)
        saveShortcuts(shortcuts)
        renderTiles()
      })
      tile.append(link, remove)
    } else {
      tile.append(link)
    }

    tilesEl.append(tile)
  }
}

function wire(): void {
  input.placeholder = ENGINES[engine].placeholder
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      navigate(input.value)
    } else if (e.key === 'Escape') {
      input.value = ''
      input.blur()
    }
  })

  searchBar.addEventListener('keydown', (e) => e.stopPropagation())

  document.addEventListener('keydown', (e) => {
    const target = e.target as HTMLElement | null
    const typing =
      target &&
      (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)
    if (typing) return
    if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
      input.focus()
    }
    if (e.key === '/' ) {
      e.preventDefault()
      input.focus()
    }
    if (e.key === 'Escape') {
      closeEditor()
    }
  })

  const scrim = $('#editor-scrim') as HTMLElement
  scrim.addEventListener('click', closeEditor)
  $('#add-link')?.addEventListener('click', openEditor)
  $('#editor-cancel')?.addEventListener('click', closeEditor)
  $('#editor-save')?.addEventListener('click', saveEditor)

  const editorName = $('#editor-name') as HTMLInputElement
  const editorUrl = $('#editor-url') as HTMLInputElement
  for (const el of [editorName, editorUrl]) {
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault()
        saveEditor()
      } else if (e.key === 'Escape') {
        e.preventDefault()
        closeEditor()
      }
    })
  }

  window.addEventListener('focus', () => input.focus())
}

applyTheme()
greet()
renderTiles()
wire()
if (!params.has('noautofocus')) input.focus()
