import {
  app,
  BrowserWindow,
  WebContentsView,
  ipcMain,
  Menu,
  nativeTheme,
  systemPreferences,
  shell,
  session,
  clipboard,
  type MenuItemConstructorOptions,
  type WebContents,
} from 'electron'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import type {
  AppState,
  SearchEngineId,
  SettingsPatch,
  TabInfo,
  ThemeInfo,
  WindowInfo,
} from '../shared/types'

app.setName('GhostMaterial')

const ACCENT_FALLBACK = '#6a4bd8'
const CHROME_HEIGHT_DEFAULT = 105
/** Ширина панели настроек. Должна совпадать с `--gm-sheet-w` в styles.css. */
const SETTINGS_WIDTH = 430

const ENGINES: Record<SearchEngineId, { name: string; search: (q: string) => string }> = {
  yandex: { name: 'Яндекс', search: (q) => `https://yandex.ru/search/?text=${encodeURIComponent(q)}` },
  google: { name: 'Google', search: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}` },
  duckduckgo: { name: 'DuckDuckGo', search: (q) => `https://duckduckgo.com/?q=${encodeURIComponent(q)}` },
  bing: { name: 'Bing', search: (q) => `https://www.bing.com/search?q=${encodeURIComponent(q)}` },
}

interface Config {
  scheme?: 'auto' | 'light' | 'dark'
  accent?: string | null
  searchEngine?: SearchEngineId
  window?: { width: number; height: number; x?: number; y?: number; maximized?: boolean }
}

interface Tab {
  id: number
  view: WebContentsView
  title: string
  url: string
  favicon: string | null
  loading: boolean
  isNewTab: boolean
  audible: boolean
  error: TabInfo['error']
  showingErrorPage: boolean
}

const CONFIG_PATH = join(app.getPath('userData'), 'ghostmaterial.json')

let config: Config = {}
try {
  if (existsSync(CONFIG_PATH)) config = JSON.parse(readFileSync(CONFIG_PATH, 'utf8')) as Config
} catch {
  config = {}
}

let schemePref: 'auto' | 'light' | 'dark' = config.scheme ?? 'auto'
let customAccent: string | null = config.accent ?? null
let searchEngine: SearchEngineId = config.searchEngine ?? 'yandex'

function saveConfig(): void {
  try {
    if (win) {
      const bounds = win.getNormalBounds()
      config.window = {
        width: bounds.width,
        height: bounds.height,
        x: bounds.x,
        y: bounds.y,
        maximized: win.isMaximized(),
      }
    }
    writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8')
  } catch (err) {
    console.error('[config] не удалось сохранить:', err)
  }
}

function systemAccent(): string {
  try {
    const raw = systemPreferences.getAccentColor()
    if (raw && raw.length >= 6) return `#${raw.slice(0, 6)}`
  } catch {
    /* не поддерживается — берём запасной */
  }
  return ACCENT_FALLBACK
}

function currentTheme(): ThemeInfo {
  const scheme =
    schemePref === 'auto' ? (nativeTheme.shouldUseDarkColors ? 'dark' : 'light') : schemePref
  return { scheme, accent: customAccent ?? systemAccent(), motion: 'expressive' }
}

// --- состояние ---

let win: BrowserWindow | null = null
let overlayOpen = false
let chromeHeight = CHROME_HEIGHT_DEFAULT
let nextTabId = 1
let activeId: number | null = null
const tabs: Tab[] = []
const closedTabs: { url: string; title: string }[] = []

function activeTab(): Tab | undefined {
  return tabs.find((t) => t.id === activeId)
}

function windowInfo(): WindowInfo {
  return {
    maximized: win?.isMaximized() ?? false,
    fullscreen: win?.isFullScreen() ?? false,
    focused: win?.isFocused() ?? false,
  }
}

function tabInfo(t: Tab): TabInfo {
  const wc = t.view.webContents
  let canGoBack = false
  let canGoForward = false
  try {
    canGoBack = wc.navigationHistory.canGoBack()
    canGoForward = wc.navigationHistory.canGoForward()
  } catch {
    /* view уже уничтожен */
  }
  return {
    id: t.id,
    title: t.title || 'Новая вкладка',
    url: t.isNewTab ? '' : t.url,
    displayUrl: t.isNewTab ? '' : t.url,
    favicon: t.favicon,
    loading: t.loading,
    canGoBack,
    canGoForward,
    isNewTab: t.isNewTab,
    audible: t.audible,
    error: t.error,
  }
}

function appState(): AppState {
  return {
    tabs: tabs.map(tabInfo),
    activeId,
    theme: currentTheme(),
    window: windowInfo(),
    searchEngine,
    settingsOpen: overlayOpen,
  }
}

function pushState(): void {
  if (!win || win.isDestroyed()) return
  win.webContents.send('ghost:state', appState())
}

function toast(text: string): void {
  win?.webContents.send('ghost:toast', text)
}

// --- окно ---

function pageWidth(total: number): number {
  const sheet = Math.min(SETTINGS_WIDTH, Math.round(total * 0.94))
  return overlayOpen ? Math.max(0, total - sheet) : total
}

let sheetAnim: ReturnType<typeof setInterval> | null = null
let animatedWidth: number | null = null

function layout(): void {
  if (!win) return
  const [w, h] = win.getContentSize()
  const top = Math.min(Math.max(0, chromeHeight), h)
  // панель настроек живёт в chrome-renderer справа, поэтому страницу сжимаем,
  // чтобы она оставалась видимой слева, а не пряталась под панелью
  const width = animatedWidth ?? pageWidth(w)
  for (const t of tabs) {
    t.view.setBounds({ x: 0, y: top, width, height: Math.max(0, h - top) })
  }
}

function animatePageWidth(from: number, to: number): void {
  if (sheetAnim) {
    clearInterval(sheetAnim)
    sheetAnim = null
  }
  if (from === to) {
    animatedWidth = null
    layout()
    return
  }
  const started = Date.now()
  const duration = 260
  animatedWidth = from
  sheetAnim = setInterval(() => {
    const t = Math.min(1, (Date.now() - started) / duration)
    const eased = 1 - Math.pow(1 - t, 3)
    animatedWidth = Math.round(from + (to - from) * eased)
    if (t >= 1) {
      animatedWidth = null
      if (sheetAnim) clearInterval(sheetAnim)
      sheetAnim = null
    }
    layout()
  }, 15)
}

function newTabUrl(): string {
  const theme = currentTheme()
  const params = new URLSearchParams({
    scheme: theme.scheme,
    accent: theme.accent,
    engine: searchEngine,
  })
  const dev = process.env['ELECTRON_RENDERER_URL']
  const base = dev
    ? new URL('newtab.html', dev).toString()
    : pathToFileURL(join(__dirname, '../renderer/newtab.html')).toString()
  return `${base}?${params.toString()}`
}

function applyThemeToPages(): void {
  const theme = currentTheme()
  for (const t of tabs) {
    try {
      t.view.setBackgroundColor(theme.scheme === 'dark' ? '#141218' : '#ffffff')
      if (t.isNewTab) t.view.webContents.loadURL(newTabUrl())
    } catch {
      /* view уже закрыт */
    }
  }
}

function windowIcon(): string | undefined {
  const candidates = [join(app.getAppPath(), 'build', 'icon.png'), join(process.resourcesPath, 'icon.png')]
  return candidates.find((p) => existsSync(p))
}

function createWindow(): void {
  const theme = currentTheme()
  const icon = windowIcon()
  win = new BrowserWindow({
    width: config.window?.width ?? 1360,
    height: config.window?.height ?? 860,
    x: config.window?.x,
    y: config.window?.y,
    minWidth: 720,
    minHeight: 460,
    show: false,
    frame: false,
    icon,
    titleBarStyle: 'hidden',
    backgroundColor: theme.scheme === 'dark' ? '#141218' : '#fef7ff',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  })

  if (config.window?.maximized) win.maximize()

  win.once('ready-to-show', () => win?.show())

  if (process.env['ELECTRON_RENDERER_URL']) {
    void win.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    void win.loadFile(join(__dirname, '../renderer/index.html'))
  }

  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }))
  win.webContents.on('will-navigate', (e) => e.preventDefault())
  attachShortcuts(win.webContents)

  win.webContents.on('did-finish-load', () => {
    pushState()
    if (tabs.length === 0) {
      createTab()
      focusOmnibox()
    }
  })

  win.on('resize', layout)
  win.on('maximize', () => {
    layout()
    pushState()
  })
  win.on('unmaximize', () => {
    layout()
    pushState()
  })
  win.on('enter-full-screen', () => {
    layout()
    pushState()
  })
  win.on('leave-full-screen', () => {
    layout()
    pushState()
  })
  win.on('focus', pushState)
  win.on('blur', pushState)

  win.on('app-command', (_e, command) => {
    if (command === 'browser-backward') goBack()
    if (command === 'browser-forward') goForward()
  })

  let saveTimer: NodeJS.Timeout | null = null
  const scheduleSave = (): void => {
    if (saveTimer) clearTimeout(saveTimer)
    saveTimer = setTimeout(saveConfig, 600)
  }
  win.on('resize', scheduleSave)
  win.on('move', scheduleSave)
  win.on('close', saveConfig)

  win.on('closed', () => {
    win = null
  })
}

// --- вкладки ---

function normalizeInput(input: string): string {
  const text = input.trim()
  if (!text) return newTabUrl()
  if (/^(https?|file):\/\//i.test(text)) return text
  if (/^[a-z][a-z0-9+.-]*:/i.test(text)) return text
  const looksLikeHost =
    /^[^\s/]+\.[^\s]{2,}(\/.*)?$/i.test(text) ||
    /^localhost(:\d+)?(\/.*)?$/i.test(text) ||
    /^\d{1,3}(\.\d{1,3}){3}(:\d+)?(\/.*)?$/.test(text)
  if (looksLikeHost) return `https://${text}`
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) return `https://${text}`
  return ENGINES[searchEngine].search(text)
}

function errorPage(code: number, description: string, url: string): string {
  const theme = currentTheme()
  const dark = theme.scheme === 'dark'
  const bg = dark ? '#141218' : '#fef7ff'
  const fg = dark ? '#e6e0e9' : '#1d1b20'
  const muted = dark ? '#cac4d0' : '#49454f'
  const accent = theme.accent
  let host = url
  try {
    host = new URL(url).host
  } catch {
    /* оставляем как есть */
  }
  return `data:text/html;charset=utf-8,${encodeURIComponent(`<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><title>Не удалось открыть страницу</title>
<style>
  :root { color-scheme: ${dark ? 'dark' : 'light'}; }
  * { box-sizing: border-box; }
  body { margin:0; min-height:100vh; display:grid; place-items:center; background:${bg}; color:${fg};
         font-family:'Segoe UI Variable Text','Segoe UI',Roboto,system-ui,sans-serif; }
  .card { max-width:560px; padding:40px; text-align:center; }
  .ghost { font-size:64px; line-height:1; filter:grayscale(.2); }
  h1 { font-size:26px; font-weight:600; margin:18px 0 8px; letter-spacing:-.2px; }
  p { color:${muted}; line-height:1.5; margin:0 0 6px; }
  code { background:${accent}22; color:${accent}; padding:2px 6px; border-radius:6px; font-size:13px; }
  .actions { display:flex; gap:10px; justify-content:center; margin-top:24px; flex-wrap:wrap; }
  a { text-decoration:none; font-size:14px; padding:10px 22px; border-radius:999px; color:${fg}; border:1px solid ${muted}55; }
  a.primary { background:${accent}; color:#fff; border-color:transparent; }
</style></head>
<body><div class="card">
  <div class="ghost">👻</div>
  <h1>Страница не отвечает</h1>
  <p><strong>${host}</strong> не открылась.</p>
  <p><code>${description}</code> · код ${code}</p>
  <div class="actions">
    <a class="primary" href="${url}">Повторить</a>
    <a href="javascript:history.back()">Назад</a>
  </div>
</div></body></html>`)}`
}

function wireTab(tab: Tab): void {
  const wc = tab.view.webContents

  wc.on('page-title-updated', (_e, title) => {
    tab.title = title
    pushState()
  })

  wc.on('page-favicon-updated', (_e, favicons) => {
    tab.favicon = favicons[0] ?? null
    pushState()
  })

  wc.on('did-start-loading', () => {
    tab.loading = true
    tab.error = null
    pushState()
  })

  wc.on('did-stop-loading', () => {
    tab.loading = false
    pushState()
  })

  wc.on('did-start-navigation', (_e, url, _isInPlace, isMainFrame) => {
    if (!isMainFrame) return
    tab.error = null
    tab.showingErrorPage = false
    if (!tab.isNewTab) tab.url = url
  })

  wc.on('did-navigate', (_e, url) => {
    if (url.startsWith('data:text/html') && tab.showingErrorPage) return
    if (url.startsWith('file:') && url.includes('newtab.html')) {
      tab.isNewTab = true
      tab.url = ''
      tab.favicon = null
      tab.title = 'Новая вкладка'
    } else {
      tab.isNewTab = false
      tab.url = url
    }
    pushState()
  })

  wc.on('did-navigate-in-page', (_e, url, isMainFrame) => {
    if (!isMainFrame) return
    tab.url = url
    tab.isNewTab = false
    pushState()
  })

  wc.on('did-fail-load', (_e, code, description, validatedURL, isMainFrame) => {
    if (!isMainFrame || code === -3) return
    tab.loading = false
    tab.error = { code, description, url: validatedURL }
    tab.showingErrorPage = true
    void wc.loadURL(errorPage(code, description, validatedURL))
    pushState()
  })

  wc.on('media-started-playing', () => {
    tab.audible = true
    pushState()
  })
  wc.on('media-paused', () => {
    tab.audible = false
    pushState()
  })

  wc.on('enter-html-full-screen', () => win?.setFullScreen(true))
  wc.on('leave-html-full-screen', () => win?.setFullScreen(false))

  wc.setWindowOpenHandler(({ url, disposition }) => {
    if (/^(https?|file):/i.test(url)) {
      createTab({ url, background: disposition === 'background-tab' })
    } else if (!url.startsWith('about:')) {
      void shell.openExternal(url)
    }
    return { action: 'deny' }
  })

  wc.on('will-navigate', (e, url) => {
    if (!/^(https?|file|data):/i.test(url)) {
      e.preventDefault()
      void shell.openExternal(url)
    }
  })

  wc.on('context-menu', (_e, params) => {
    const items: MenuItemConstructorOptions[] = []
    if (params.linkURL) {
      items.push(
        {
          label: 'Открыть ссылку в новой вкладке',
          click: () => createTab({ url: params.linkURL, background: true }),
        },
        {
          label: 'Копировать адрес ссылки',
          click: () => clipboard.writeText(params.linkURL),
        },
        { type: 'separator' },
      )
    }
    if (params.selectionText) {
      items.push({ role: 'copy', label: 'Копировать' }, { type: 'separator' })
    }
    if (params.isEditable) {
      items.push(
        { role: 'cut', label: 'Вырезать' },
        { role: 'copy', label: 'Копировать' },
        { role: 'paste', label: 'Вставить' },
        { type: 'separator' },
      )
    }
    if (params.srcURL) {
      items.push(
        { label: 'Открыть изображение', click: () => createTab({ url: params.srcURL }) },
        { label: 'Копировать адрес изображения', click: () => clipboard.writeText(params.srcURL) },
        { type: 'separator' },
      )
    }
    items.push(
      { label: 'Назад', enabled: wc.navigationHistory.canGoBack(), click: goBack },
      { label: 'Вперёд', enabled: wc.navigationHistory.canGoForward(), click: goForward },
      { label: 'Обновить', click: () => wc.reload() },
      { type: 'separator' },
      { label: 'Показать код страницы', click: () => wc.openDevTools({ mode: 'detach' }) },
    )
    Menu.buildFromTemplate(items).popup({ window: win ?? undefined })
  })

  attachShortcuts(wc)
}

function createTab(options: { url?: string; background?: boolean } = {}): Tab {
  if (!win) throw new Error('окно ещё не создано')
  const view = new WebContentsView({
    webPreferences: {
      partition: 'persist:ghost',
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: true,
    },
  })
  const theme = currentTheme()
  view.setBackgroundColor(theme.scheme === 'dark' ? '#141218' : '#ffffff')

  const tab: Tab = {
    id: nextTabId++,
    view,
    title: 'Новая вкладка',
    url: '',
    favicon: null,
    loading: false,
    isNewTab: !options.url,
    audible: false,
    error: null,
    showingErrorPage: false,
  }

  view.webContents.setAudioMuted(false)
  win.contentView.addChildView(view)
  tabs.push(tab)
  wireTab(tab)

  const target = options.url ? normalizeInput(options.url) : newTabUrl()
  void view.webContents.loadURL(target)

  if (options.background) {
    view.setVisible(false)
  } else {
    selectTab(tab.id)
  }
  layout()
  pushState()
  return tab
}

function selectTab(id: number): void {
  const tab = tabs.find((t) => t.id === id)
  if (!tab) return
  activeId = id
  for (const t of tabs) t.view.setVisible(t.id === id)
  if (!overlayOpen) tab.view.webContents.focus()
  layout()
  pushState()
}

function closeTab(id: number): void {
  const index = tabs.findIndex((t) => t.id === id)
  if (index < 0) return
  const [tab] = tabs.splice(index, 1)
  if (!tab.isNewTab && tab.url) {
    closedTabs.push({ url: tab.url, title: tab.title })
    if (closedTabs.length > 25) closedTabs.shift()
  }
  if (activeId === id) activeId = null
  try {
    win?.contentView.removeChildView(tab.view)
    tab.view.webContents.close()
  } catch {
    /* уже уничтожено */
  }

  if (tabs.length === 0) {
    createTab()
    return
  }
  if (activeId === null) {
    const next = tabs[Math.min(index, tabs.length - 1)]
    selectTab(next.id)
  } else {
    layout()
    pushState()
  }
}

function reopenTab(): void {
  const last = closedTabs.pop()
  if (last) createTab({ url: last.url })
}

function cycleTab(delta: number): void {
  if (tabs.length < 2) return
  const current = tabs.findIndex((t) => t.id === activeId)
  const next = (current + delta + tabs.length) % tabs.length
  selectTab(tabs[next].id)
}

function goBack(): void {
  const t = activeTab()
  if (t?.view.webContents.navigationHistory.canGoBack()) t.view.webContents.navigationHistory.goBack()
}

function goForward(): void {
  const t = activeTab()
  if (t?.view.webContents.navigationHistory.canGoForward())
    t.view.webContents.navigationHistory.goForward()
}

function focusOmnibox(): void {
  if (!win) return
  win.webContents.focus()
  win.webContents.send('ghost:focus-omnibox')
}

function setOverlay(open: boolean): void {
  if (!win) {
    overlayOpen = open
    return
  }
  const [w] = win.getContentSize()
  const from = animatedWidth ?? pageWidth(w)
  overlayOpen = open
  animatedWidth = null
  const to = pageWidth(w)
  // страница остаётся видимой: при открытых настройках она занимает левую часть окна
  for (const t of tabs) t.view.setVisible(t.id === activeId)
  if (!open) activeTab()?.view.webContents.focus()
  layout()
  animatePageWidth(from, to)
  pushState()
}

function attachShortcuts(wc: WebContents): void {
  wc.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return
    const ctrl = input.control || input.meta
    const shift = input.shift
    const alt = input.alt
    const key = input.key.toLowerCase()
    const prevent = (): void => event.preventDefault()

    if (input.key === 'F11') {
      prevent()
      win?.setFullScreen(!win.isFullScreen())
      return
    }
    if (input.key === 'F12') {
      prevent()
      activeTab()?.view.webContents.toggleDevTools()
      return
    }
    if (input.key === 'F5') {
      prevent()
      const wcActive = activeTab()?.view.webContents
      if (!wcActive) return
      if (shift) wcActive.reloadIgnoringCache()
      else wcActive.reload()
      return
    }
    if (alt && key === 'arrowleft') {
      prevent()
      goBack()
      return
    }
    if (alt && key === 'arrowright') {
      prevent()
      goForward()
      return
    }
    if (ctrl) {
      if (key === 't' && !shift) {
        prevent()
        createTab()
        return
      }
      if (key === 't' && shift) {
        prevent()
        reopenTab()
        return
      }
      if (key === 'w') {
        prevent()
        if (activeId !== null) closeTab(activeId)
        return
      }
      if (key === 'l' || key === 'k') {
        prevent()
        focusOmnibox()
        return
      }
      if (key === 'r') {
        prevent()
        const wcActive = activeTab()?.view.webContents
        if (!wcActive) return
        if (shift) wcActive.reloadIgnoringCache()
        else wcActive.reload()
        return
      }
      if (key === 'tab') {
        prevent()
        cycleTab(shift ? -1 : 1)
        return
      }
      if (key === 'i' && shift) {
        prevent()
        activeTab()?.view.webContents.toggleDevTools()
        return
      }
      if (key === '=' || key === '+') {
        prevent()
        const wcActive = activeTab()?.view.webContents
        if (wcActive) wcActive.setZoomLevel(wcActive.getZoomLevel() + 0.5)
        return
      }
      if (key === '-') {
        prevent()
        const wcActive = activeTab()?.view.webContents
        if (wcActive) wcActive.setZoomLevel(wcActive.getZoomLevel() - 0.5)
        return
      }
      if (key === '0') {
        prevent()
        activeTab()?.view.webContents.setZoomLevel(0)
        return
      }
      if (/^[1-9]$/.test(key)) {
        prevent()
        const index = key === '9' ? tabs.length - 1 : Number(key) - 1
        const target = tabs[index]
        if (target) selectTab(target.id)
        return
      }
    }
    if (key === 'escape' && overlayOpen) {
      prevent()
      win?.webContents.send('ghost:close-overlay')
    }
  })
}

// --- IPC ---

function registerIpc(): void {
  ipcMain.handle('ghost:state', () => appState())

  ipcMain.handle('tabs:create', (_e, url?: string, background?: boolean) => {
    const tab = createTab({ url, background })
    if (!background) focusOmnibox()
    return tab.id
  })
  ipcMain.handle('tabs:close', (_e, id: number) => closeTab(id))
  ipcMain.handle('tabs:select', (_e, id: number) => selectTab(id))
  ipcMain.handle('tabs:reopen', () => reopenTab())

  ipcMain.handle('tabs:navigate', (_e, id: number, input: string) => {
    const tab = tabs.find((t) => t.id === id)
    if (!tab) return
    const target = normalizeInput(input)
    tab.isNewTab = target.startsWith('file:') && target.includes('newtab.html')
    if (tab.isNewTab) {
      tab.url = ''
      tab.title = 'Новая вкладка'
      tab.favicon = null
    }
    void tab.view.webContents.loadURL(target)
    tab.view.webContents.focus()
  })

  ipcMain.handle('nav:action', (_e, action: string) => {
    const tab = activeTab()
    if (!tab) return
    const wc = tab.view.webContents
    switch (action) {
      case 'back':
        goBack()
        break
      case 'forward':
        goForward()
        break
      case 'reload':
        wc.reload()
        break
      case 'hard-reload':
        wc.reloadIgnoringCache()
        break
      case 'stop':
        wc.stop()
        break
      case 'home':
        void wc.loadURL(newTabUrl())
        break
    }
  })

  ipcMain.handle('nav:zoom', (_e, delta: number | 'reset') => {
    const wc = activeTab()?.view.webContents
    if (!wc) return
    if (delta === 'reset') wc.setZoomLevel(0)
    else wc.setZoomLevel(wc.getZoomLevel() + delta)
  })

  ipcMain.handle('nav:devtools', () => {
    activeTab()?.view.webContents.toggleDevTools()
  })

  ipcMain.handle('ui:overlay', (_e, open: boolean) => setOverlay(open))

  ipcMain.handle('settings:get', () => ({
    scheme: schemePref,
    accent: customAccent,
    searchEngine,
  }))

  ipcMain.handle('settings:apply', (_e, patch: SettingsPatch) => {
    if (patch.scheme) schemePref = patch.scheme
    if (patch.accent !== undefined) customAccent = patch.accent
    if (patch.searchEngine) searchEngine = patch.searchEngine
    config.scheme = schemePref
    config.accent = customAccent
    config.searchEngine = searchEngine
    saveConfig()
    applyThemeToPages()
    pushState()
    return appState()
  })

  ipcMain.on('ui:chrome-height', (_e, height: number) => {
    const next = Math.max(0, Math.round(height))
    if (Math.abs(next - chromeHeight) < 1) return
    chromeHeight = next
    layout()
  })

  ipcMain.on('win:minimize', () => win?.minimize())
  ipcMain.on('win:toggle-maximize', () => {
    if (!win) return
    if (win.isMaximized()) win.unmaximize()
    else win.maximize()
  })
  ipcMain.on('win:close', () => win?.close())
  ipcMain.on('win:toggle-fullscreen', () => {
    if (!win) return
    win.setFullScreen(!win.isFullScreen())
  })
}

// --- сессия ---

function setupSession(): void {
  const ses = session.fromPartition('persist:ghost')
  ses.setPermissionRequestHandler((_wc, permission, callback) => {
    const allowed = new Set([
      'fullscreen',
      'pointerLock',
      'clipboard-sanitized-write',
      'notifications',
    ])
    callback(allowed.has(permission))
  })
  ses.on('will-download', (_e, item) => {
    toast(`Скачивание: ${item.getFilename()}`)
    item.once('done', (_evt, state) => {
      if (state === 'completed') toast(`Готово: ${item.getFilename()}`)
      else toast(`Скачивание прервано: ${item.getFilename()}`)
    })
  })
}

// --- запуск ---

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (!win) return
    if (win.isMinimized()) win.restore()
    win.focus()
  })

  app.whenReady().then(() => {
    // убираем следы Electron из User-Agent — иначе часть сайтов ругается
    app.userAgentFallback = app.userAgentFallback
      .replace(/\sGhostMaterial\/[\d.]+/i, '')
      .replace(/\sElectron\/[\d.]+/i, '')

    Menu.setApplicationMenu(null)
    setupSession()
    registerIpc()
    createWindow()

    nativeTheme.on('updated', () => {
      applyThemeToPages()
      pushState()
    })
    try {
      systemPreferences.on('accent-color-changed', () => {
        applyThemeToPages()
        pushState()
      })
    } catch {
      /* не поддерживается */
    }

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
  })

  app.on('window-all-closed', () => {
    app.quit()
  })
}
