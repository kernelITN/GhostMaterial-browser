import { contextBridge, ipcRenderer } from 'electron'
import type { AppState, GhostApi, SettingsPatch } from '../shared/types'

const api: GhostApi = {
  platform: process.platform,
  version: process.versions.electron,
  chromeVersion: process.versions.chrome,
  invoke: {
    state: () => ipcRenderer.invoke('ghost:state'),
    createTab: (url?: string, background?: boolean) =>
      ipcRenderer.invoke('tabs:create', url, background),
    closeTab: (id: number) => ipcRenderer.invoke('tabs:close', id),
    selectTab: (id: number) => ipcRenderer.invoke('tabs:select', id),
    reopenTab: () => ipcRenderer.invoke('tabs:reopen'),
    navigate: (id: number, url: string) => ipcRenderer.invoke('tabs:navigate', id, url),
    nav: (action: string) => ipcRenderer.invoke('nav:action', action),
    setZoom: (delta: number | 'reset') => ipcRenderer.invoke('nav:zoom', delta),
    toggleDevTools: () => ipcRenderer.invoke('nav:devtools'),
    setOverlay: (open: boolean) => ipcRenderer.invoke('ui:overlay', open),
    applySettings: (patch: SettingsPatch) => ipcRenderer.invoke('settings:apply', patch),
    getSettings: () => ipcRenderer.invoke('settings:get'),
  },
  window: {
    minimize: () => ipcRenderer.send('win:minimize'),
    toggleMaximize: () => ipcRenderer.send('win:toggle-maximize'),
    close: () => ipcRenderer.send('win:close'),
    toggleFullscreen: () => ipcRenderer.send('win:toggle-fullscreen'),
  },
  setChromeHeight: (height: number) => ipcRenderer.send('ui:chrome-height', height),
  onState: (cb: (state: AppState) => void) => {
    const handler = (_e: Electron.IpcRendererEvent, state: AppState): void => cb(state)
    ipcRenderer.on('ghost:state', handler)
    return () => ipcRenderer.removeListener('ghost:state', handler)
  },
  onFocusOmnibox: (cb: () => void) => {
    const handler = (): void => cb()
    ipcRenderer.on('ghost:focus-omnibox', handler)
    return () => ipcRenderer.removeListener('ghost:focus-omnibox', handler)
  },
  onCloseOverlay: (cb: () => void) => {
    const handler = (): void => cb()
    ipcRenderer.on('ghost:close-overlay', handler)
    return () => ipcRenderer.removeListener('ghost:close-overlay', handler)
  },
  onToast: (cb: (text: string) => void) => {
    const handler = (_e: Electron.IpcRendererEvent, text: string): void => cb(text)
    ipcRenderer.on('ghost:toast', handler)
    return () => ipcRenderer.removeListener('ghost:toast', handler)
  },
}

contextBridge.exposeInMainWorld('ghost', api)
