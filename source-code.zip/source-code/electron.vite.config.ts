import { resolve } from 'node:path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin()],
  },
  preload: {
    plugins: [externalizeDepsPlugin()],
  },
  renderer: {
    build: {
      rollupOptions: {
        input: {
          index: resolve(process.cwd(), 'src/renderer/index.html'),
          newtab: resolve(process.cwd(), 'src/renderer/newtab.html'),
        },
      },
    },
  },
})
